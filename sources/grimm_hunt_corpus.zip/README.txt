格林童话语料（CUS6043 小组专题用）

来源：Jacob & Wilhelm Grimm, Household Tales, Margaret Hunt 英译（1884，译自 1857 年第七版）。
文本取自 Standard Ebooks 校订版：https://standardebooks.org/ebooks/jacob-grimm_wilhelm-grimm/household-tales/margaret-hunt
版权：原文与译文为公版；Standard Ebooks 的校订工作以 CC0 释出。可放入网页的 data 文件夹。

内容：
- tales/：每篇一个 .txt，共 201 篇（KHM 1–200，另含 151*《The Twelve Idle Servants》）。文件名开头是「序号」，对应标注表的「序号」栏，不一定等于 KHM 编号（序号 152 以后 = KHM 减 1）。
- grimm_hunt_corpus.txt：全部 201 篇合并成一个文件，每篇以「=== 序号 篇名 ===」分隔，可直接上传 Voyant Tools。
- tales_stats.csv：每篇的字数，以及王室词、财富词、贫困词的出现次数与每千词频率。
- lexicon.json：上述三类词的正则词表。
已剔除：10 篇儿童圣徒传说（Children's Legends）。
